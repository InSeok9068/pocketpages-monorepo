# pocketpages-plugin-auth

## 0.3.0

### Minor Changes

- 6ca2b50: Support PocketBase MFA: `signInWithPassword()` and `signInWithOTP()` accept `{ mfaId }` to complete the second step after a first sign-in fails with a 401 whose `response.mfaId` is set.

### Patch Changes

- Updated dependencies [8c89297]
  - pocketpages-plugin-js-sdk@0.3.0

## 0.2.2

### Patch Changes

- 7d9eab4: Fix: fetch auth record from cookie token
- e4987ba: Fix: do not allow signIn() without a valid auth record

## 0.2.1

### Patch Changes

- a05520c: Enh: auth now uses cookieToken rather than newToken (more efficient)

## 0.2.0

### Minor Changes

- 8fef39f: Plugins now require a `name` field

### Patch Changes

- Updated dependencies [8fef39f]
  - pocketpages-plugin-js-sdk@0.1.0

## 0.1.1

### Patch Changes

- df9995a: Fix: make js-sdk a required dep

## 0.1.0

### Minor Changes

- 4286e4f: Renamed signInWithToken to signIn and fixed cookie writing bug

### Patch Changes

- Updated dependencies [d80bbb2]
  - pocketpages-plugin-js-sdk@0.0.9

## 0.0.8

### Patch Changes

- Fix: build
- Updated dependencies
  - pocketpages-plugin-js-sdk@0.0.8

## 0.0.7

### Patch Changes

- 79dc05d: Fix: update pocketbase-js-sdk-jsvm
- Updated dependencies [79dc05d]
  - pocketpages-plugin-js-sdk@0.0.7

## 0.0.6

### Patch Changes

- Fix: bad build
- Updated dependencies
  - pocketpages-plugin-js-sdk@0.0.6

## 0.0.5

### Patch Changes

- a612d93: Fix: renamed global plugin config context to globalApi
- Updated dependencies [a612d93]
  - pocketpages-plugin-js-sdk@0.0.5

## 0.0.4

### Patch Changes

- Removed workspace protocol from dependencies
- Updated dependencies
  - pocketpages-plugin-js-sdk@0.0.4

## 0.0.3

- Initial release
